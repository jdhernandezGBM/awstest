# Artefacto Scaffolding Python
Esta app está desarrollada en Python 3, con ayuda del paquete CookieCutter.

El objetivo de esta funcionalidad es crear una estructura base para los componentes que se deban realizar en el área de Batch del proyecto. La intención es crear una funcionalidad de fácil uso y que cubra la mayoría de las necesidades base que pueda tener cualquier componente, como lo es una estructura de carpetas base, iniciar el repositorio del proyecto, crear entornos virtuales y demás.

Todo el desarrollo de esta funcionalidad estuvo basado en la librería de Python Cookiecutter en la versión 1.7.3.

##**Ventajas de cokiecutter:**
- Multiplataforma, funciona para Linux, Windows y Mac.
- Compatible con Python 2 y 3.
- Las plantillas pueden estar sobre multiples formatos de archivos tales como Python, JavaScript, Ruby, MarkDown, CSS, HTML, entre otros.
- Las plantillas pueden ser almacenadas en algún repositorio remoto y ser llamadas a través de consola con un simple comando.
- Se puede ejecutar directamente con código en Python.

**NOTA:** Es importante tener en cuenta que si se desea crear un repositorio, un init inicial, un push, etc, se debe tener instalado git con sus correspondientes credenciales.

A continuación, se presenta la estructura detallada de esta plantilla.

![Estructura de carpetas](images/folder.jpg)
 
•	**template-dags-v2:** Es la carpeta con la primera plantilla creada, que, para este avance, se enfocó en generar una primera versión para dags de AirFlow.

•	**template-dags/{{cookiecutter.app_name}}/:** Es una carpeta con un nombre en un formato definido por la librería cookiecutter para que, al generar la plantilla, la carpeta tome el nombre de la variable de entrada “app_name”. 

•	**template-dags/{{cookiecutter.app_name}}/(dags or job)/:** Carpeta principal de la plantilla, donde se ubican los dags de Airflow o los jobs de Glue.

•	**template-dags/{{cookiecutter.app_name}}/(dags or job)/{{cookiecutter.module_name}}.py:** Archivo en formato .py, que contiene un ejemplo de la tecnologia que se seleccione con la variable ETL_tool.

•	**template-dags/{{cookiecutter.app_name}}/test/:** Carpeta donde deben ir los test de las clases que se creen dentro de la carpeta src.

•	**template-dags/{{cookiecutter.app_name}}/Makefile:** Es un archivo  que contiene comandos ejecutables a partir de la instrucción make en la terminal, permite instalar requerimientos, ejecutar tests de la carpeta test y crear el archivo de requerimientos de forma automática (En el template-dags/{{cookiecutter.app_name}}/readme.md se detalla más este componente).

•	**template-dags/{{cookiecutter.app_name}}/README.md:** Es el archivo base de markdown para describir el componente que se esté creando.

•	**template-dags/{{cookiecutter.app_name}}/requirements.txt:** Es el archivo base de requerimientos para esta plantilla.

•	**template-dags/hooks/:** En esta carpeta, cookiecutter ejecuta el archivo .py llamado "post_gen_project", el cual aplica ciertas configuraciones las cuales pueden ser programadas con Python.

•	**template-dags/cookiecutter.json:** Es el archivo donde se definen las variables que se recibirán al momento de crear las plantillas, los nombres que se utilicen en estas variables deben ser los mismos que se utilizan en la estructura de llaves para asignarle nombres a carpetas, archivos y valores a líneas de código que dependan de estos parámetros dentro de los scripts o archivos.

•	**template-dags/README.md:** Es el archivo que describe todos los pasos para utilizar y crear nuevas versiones de esta plantilla.

•	**template-dags/requieriments.txt:** Es el archivo que todos los requerimientos de python para utilizar y crear nuevas versiones de esta plantilla.

## Agregar, editar o eliminar variables de entrada
Para cualquiera de estos procesos, se debe dirigir al archivo cookiecutter.json
 
```json
{
   "app_name":"myFirstApp",
   "ETL_tool":"airflow/glue/stepfunctions/lambda",
   "module_name":"app",
   "version_app":"v1.0.0",   
   "create_env":"y/n",
   "name_env":"",
   "url_repository":"",
   "branch":"main",
   "init_push":"y/n",
   "author":""
}
```

Debe tener una estructura como la que se muestra en la imagen anterior, para ese ejemplo, todas estas variables se deben configurar al momento de crear nuestras plantillas. 

Si se desea editar una de estas variables o sus valores por defecto, sólo se debe cambiar los valores objetivo; si desea eliminar alguna, puede borrar la línea donde se encuentra la variable y su valor, si desea agregar una variable, puede hacerlo en el formato definido por la estructura JSON, donde se tiene una llave (nombre de variable, se encuentran en color azul en la imagen anterior) y un valor (valor de variable, se encuentran en color café en la imagen anterior), las llaves y valores deben estar separados por doble punto “:” y entre variables y valores, se separan por comas “,”. Por ejemplo, para agregar la llave “test”, con valor “default”.


## **Agregar, editar o eliminar carpetas, archivos y líneas de código dinámica**

Se pueden agregar, eliminar o editar carpetas, archivos y líneas de código dinámicas en las plantillas. Para crear dichos componentes, se deben crear inicialmente de forma manual dentro del proyecto, en el lugar donde se desee de la plantilla, pero considerando que siempre deben llevar por nombre la estructura definida por el paquete cookiecutter, que es {{cookiecutter.<nombre de variable de entrada>}}, de esta forma al crear las carpetas, archivos y líneas de código, la herramienta entiende que al encontrar esta estructura, debe remplazar acá, el valor de la variable a la que hace referencia.

Si se desea eliminar estos archivos se debe realizar directamente de la plantilla, y al crear nuevos ejemplos, no se tendrá en cuenta el archivo eliminado. 

Para editar, se debe seguir los mismos pasos, ir al archivo, carpeta o línea de código objetivo y editar el nombre de la variable que se va a definir.

Los nombres se le pueden agregar prefijos, sufijos y extensiones sin mayor problema, es decir, si tengo la variable “test”, con valor “gran”, puedo crear una carpeta con la estructura “mi_primer_{{cookiecutter.test}}_project.py” y al usar la plantilla para crear un proyecto, la carpeta tendrá por nombre “mi_primer_gran_project.py”.

## **Hooks**

Los Hooks son archivos ejecutables por cookiecutter mientras se esté creando las plantillas. Permiten crear configuraciones más detalladas en nuestros proyectos, tales como, utilizar líneas de código para ejecutar comandos de terminal utilizando condiciones, ciclos y demás, que modifiquen dinámicamente la estructura de nuestro proyecto, en base a unos parámetros de entrada definidos, por ejemplo, si en esta plantilla, la variable, create_env se define cono “y”, ejecutará las siguientes líneas de código:

```python
create_env_opt_1 = "{{cookiecutter.create_env}}" == "y".lower()
create_env_opt_2 = "{{cookiecutter.create_env}}" == "yes".lower()
exists_name = "{{cookiecutter.name_env}}" != ""

if (create_env_opt_1 or create_env_opt_2) and exists_name:
    print("Creating virual environment")

    try:
        subprocess.call(["virtualenv", f"env_{{cookiecutter.name_env}}"])
        print("Virual environment created")

        subprocess.call(["pip", "install", "coverage==6.0.2"])

    except Exception as err:
        print("Fail to create enviroment:", str(err))
```
 
En caso de que no se defina el valor, no entrará a esta condición y el entorno no será creado.

De esta misma forma, con la librería subprocess, se pueden crear otros procesos, tales como iniciar git, como se muestra a continuación.
 
```python
# IMPORTANTE: el equipo debe tener instalado GIT para que esta sesion sea funcional.

subprocess.call(["git", "init"])
subprocess.call(["git", "add", "*"])
subprocess.call(["git", "commit", "-m", "Initial commit"])
subprocess.call(["git", "branch", "-M", "{{cookiecutter.branch}}"])
```

O eliminar, crear, o editar carpetas en base a variables de entrada

# Iniciar con la plantilla
### Paso 1: 
Para poder crear tu plantilla, debes instalar python 3.

### Windows:
Puedes instalarlo por medio de Microsoft Store, o descargalo desde la página oficial: https://www.python.org/downloads/

### Linux/Ubuntu:
En la terminal, escribe el siguiente comando: 
**sudo apt-get install python3.7**

### Linux/AWS Linux/RedHat o derivados:
En la terminal, escribe el siguiente comando: 
**sudo yum install python37**

## Paso 2

Debes instalar todas las dependencias con el gestor de paquetes de Python. Desde la terminal o CMD, escribe:

**pip install -r requirements.txt**

En caso de que no te funcione, puedes remplazar pip por pip3.

Si no tienes instalado el gestor de paquetes **pip** puedes instalarlo de la siguiente forma:

### Windows:
Viene instalado desde Microsoft Store.

### Linux/Ubuntu:
En la terminal, escribe el siguiente comando: 
**sudo apt-get install python3-pip**

### Linux/AWS Linux/RedHat o derivados:
En la terminal, escribe el siguiente comando: 
**sudo yum install python3-pip**

## Paso 3
Para crear tu plantilla de codigo, sólo debes ejecutar en la terminal o CMD (este comando sirve cuando tienes tu plantilla en una carpeta local):

**cookiecutter <path_to_template_file>**

Ejemplo: 

**cookiecutter templates-dags/**

Es importante recalcar que la carpeta templates-dags/ es donde se encuentra el archivo cookiecutter.json, la estructura del template y los hooks.

#### Para crear un template desde git:

**cookiecutter <git_url>**

Ejemplo: 

**cookiecutter https://github.com/user/template-scaffolding.git**

## Iniciando en la plantilla

Una vez dentro de la plantilla:

Podras instalar las dependencias iniciales con el comando **make start** (recuerda entrar al entorno antes de lanzar el comando, para que las instalaciones se hagan dentro del env que creaste).

Si quieres entrar en el entorno que creaste, ejecuta **source <name_env>/bin/activate**

Si quieres salir del entorno, ejecuta **deactivate**

Si quieres ejecutar todos los test files **dentro de la carpeta test/**, ejecuta **make test**

Una vez terminado tu desarrollo, puedes ejecutar **make build** para generar un archivo requirements.txt con todas las dependencias de tu aplicación.
