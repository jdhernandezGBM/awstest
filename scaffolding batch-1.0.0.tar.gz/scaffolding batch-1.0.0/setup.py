import setuptools

setuptools.setup(
    name="scaffolding batch",
    version="1.0.0",
    author="Equipo Accenture Batch",
    package_dir={"": "src"},
    packages=setuptools.find_packages(where="src"),
    python_requires=">=3.7",
)